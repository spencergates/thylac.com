Double-click curve to launch game.
Settings may be changed in resources/preferences.yaml.

Controls:
- WASD: movement
- Mouse: look
- Right mouse click: hold and drag to look up/down
- Scroll: zoom in/out
- Enter: go to next level
- R: reset level
- Tab: fly mode
- O: change ball texture